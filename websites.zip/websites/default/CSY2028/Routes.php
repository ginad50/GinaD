<?php
namespace CSY2028;
interface Routes {
	// public function callControllerAction($route);
	public function getRoutes();
	public function checkLogin();
}