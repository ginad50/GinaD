<?php
namespace Job\Controllers;

class Applicant {
	private $applicantsTable;
	private $jobsTable;

	public function __construct($applicantsTable, $jobsTable) {
		$this->applicantsTable = $applicantsTable;
		$this->jobsTable = $jobsTable;
	}

	public function list() {
		$applicants = $this->applicantsTable->find('jobId', $_GET['id']);

		if (isset($_GET['id'])){
			$result = $this->jobsTable->find('id', $_GET['id']);
			$job = $result[0];
		}

		$applicantCount = $this->applicantsTable->count('jobId', $_GET['id']);
		// $applicantCount = $resultCount;
		// echo $applicantCount['count'];
		echo $applicantCount['count'];
		
		return [
			'template' => 'applicantlist.html.php',
			'title' => 'Applicant List',
			'variables' => [
			'applicants' => $applicants, 'job' => $job, 'applicantCount' => $applicantCount['count']
			]
		];
	}		


	public function editSubmit() {
		$applicant = $_POST['applicant'];
		
		$this->applicantsTable->save($applicant);

		header('location: /applicant/list');
	
	}
	
	public function editForm() {
		// if (isset($_GET['id'])) {
		// 	$result = $this->applicantsTable->find('id', $_GET['id']);
		// 	$applicant = $result[0];	
		// } else {
		// 	$applicant = false;
		// }
		$result = $this->jobsTable->find('id', $_GET['id']);
				$jobs = $result[0];
				echo $jobs['id'];
				$applicant = false;
		return [
			'template' => 'editapplicant.html.php',
			'variables' => ['applicant' => $applicant, 'job' => $jobs],
			'title' => 'Edit Applicant'
		];
		header('location: /applicant/list');
	
	}

	public function edit() {
		if  (isset($_GET['id'])) {
			if (isset($_POST['applicant'])) {
				echo 'Am I in this function?';
		
				$applicant = $_POST['applicant'];
				$this->applicantsTable->save($applicant);

				header('location: /job/list');
			}
			else {
			
				// This is job id not applicant id
				// $id = $_GET['id'];
				// echo $id;
				
				// $result = $this->applicantsTable->find('id', $_GET['id']);
				// $applicant = $result[0];

				$result = $this->jobsTable->find('id', $_GET['id']);
				$jobs = $result[0];
				echo $jobs['id'];
				$applicant = false;

				return [
					'template' => 'editapplicant.html.php',
					'variables' => ['applicant' => $applicant, 'job' => $jobs],
					// 'variables' => ['applicant' => $applicant, 'job' => $this->jobsTable->findAll()],
					'title' => 'Edit Applicant'
				];
			}
		} else  {
				$applicant = false;
			}
	}
}
