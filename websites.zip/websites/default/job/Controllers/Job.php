<?php
namespace Job\Controllers;
class Job {
	private $jobsTable;
	private $categoriesTable;
	private $applicantsTable;
	private $usersTable;

	
	public function __construct($jobsTable, $categoriesTable, $applicantsTable, $usersTable) {
		
		$this->jobsTable = $jobsTable;
		$this->categoriesTable = $categoriesTable;
		$this->applicantsTable = $applicantsTable;
		$this->usersTable = $usersTable;   

		
	}

	public function list() {
		// $jobs = new \job\Entity\Job($this->jobsTable);
		// echo '<pre>',print_r($jobs);

		
		$jobs = $this->jobsTable->findAll();
		// $jobs = $this->$jobsTable->findAll('id',1)[0];
		

		// echo $job->id;
		// echo $job->title;
		// echo $job->getAuthor()->name;

		return ['template' => 'joblist.html.php',
		'title' => 'Job List',
		'variables' => [
				'jobs' => $jobs
			]
		];
	}

	public function delete() {
		$this->jobsTable->delete($_POST['id']);

		header('location: /job/list');
	}

	public function home() {
		$job = $this->jobsTable->find('id', 1);

		return [
			'template' => 'home.html.php',
			'variables' => ['job' => $job[0]],
			'title' => "Jo's Jobs"
		];

	}

	public function editSubmit() {
		$job = $_POST['job'];
		
		echo $job['title'];
		$this->jobsTable->save($job);

		header('location: /job/list');
	
	}

	
	public function editForm() {
		if (isset($_GET['id'])) {
			$result = $this->jobsTable->find('id', $_GET['id']);
			$job = $result[0];	
		} else {
			$job = false;
		}
		return [
			'template' => 'editjob.html.php',
			'variables' => ['job' => $job,'categories' => $this->categoriesTable->findAll()],
			'title' => 'Edit Job'
		];
		header('location: /job/list');
	
	}


	public function edit() {
		if (isset($_POST['job'])) {

			// $date = new \DateTime();
			// $job = $_POST['job'];
			// $job['closingDate'] = $date->format('Y-m-d H:i:s');
			echo $job['title'];
			$this->jobsTable->save($_POST['job']);

			header('location: /job/list');
		}
		else {
			if  (isset($_GET['id'])) {
				$result = $this->jobsTable->find('id', $_GET['id']);
				$job = $result[0];
			}
			else  {
				$job = false;
			}

			return [
				'template' => 'editjob.html.php',
				// 'variables' => ['job' => $job,'categories' => $this->categoriesTable->findAll()],
				'variables' => ['job' => $job,'categories' => $this->categoriesTable->findAll()],
				'title' => 'Edit Job'
			];
		}
	}
}
