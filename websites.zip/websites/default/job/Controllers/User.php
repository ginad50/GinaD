<?php
namespace Job\Controllers;
session_start();
class User {
	private $usersTable;

	public function __construct($usersTable) {
		$this->usersTable = $usersTable;
	}

	public function login() {
		if (isset($_POST['submit'])) {
			$result = $this->usersTable->find('username', $_POST['username']);
			$user = $result[0];
			
			$username = $user['username'];
			$password = $user['password'];
			
			if ($_POST['password'] == $password){

				$_SESSION['loggedin'] = true;
				$_SESSION['loggeduser'] = $username;
				$_SESSION['loggedtype'] = $usertype;
				header('location: /job/list');
			} else {
				header('location: /login/login');
			}
			
			
		} else {
			$user = false;
		}	
		return [
			'template' => 'login.html.php',
			'variables' => ['user' => $user],
			'variables' => [],
			'title' => 'Login'
		];
	}		

	public function logout() {
		
		unset($_SESSION['loggedin']);
		unset($_SESSION['loggeduser']);
		unset($_SESSION['usertype']);

		return [
			'template' => 'logout.html.php',
			'variables' => [],
			'variables' => [],
			'title' => 'Logout'
		];
	}		


	public function editSubmit() {
		$user = $_POST['user'];
		
		$this->usersTable->save($user);

		header('location: /job/list');
	
	}

	
	public function editForm() {
		if (isset($_GET['id'])) {
			$result = $this->usersTable->find('id', $_GET['id']);
			$user = $result[0];	
		} else {
			$user = false;
		}
		return [
			'template' => 'edituser.html.php',
			'variables' => ['user' => $user],
			'title' => 'Edit User'
		];
		header('location: /job/list');
	
	}

}
