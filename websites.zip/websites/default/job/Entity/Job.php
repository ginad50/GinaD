<?php
namespace job\Entity;
class Job {
    
    public $usersTable;
    
    public $id;
    public $title;
    public $description;
    public $salary;
    public $closingDate;
    public $categoryId;
    public $location;
    public $authorId;

    public function __construct(\CSY2028\DatabaseTable $usersTable) {
        $this->usersTable = $usersTable;
    }
    
    public function getAuthor() {
        return $this->usersTable->find('id', $this->authorId)[0];
    }
    
}
