<?php
namespace Job;

class Routes implements \CSY2028\Routes {
	private $categoriesTable;
	public function callControllerAction($route) {
		require '../database.php';

		$jobsTable = new \CSY2028\DatabaseTable($pdo, 'job', 'id');
		$this->categoriesTable = new \CSY2028\DatabaseTable($pdo, 'category', 'id');
		$userTable = new \CSY2028\DatabaseTable($pdo, 'user', 'id');		
		$applicantsTable = new \CSY2028\DatabaseTable($pdo, 'applicants', 'id');		

		$jobController = new \Job\Controllers\Job($jobsTable, $this->categoriesTable, $applicantsTable);
		$categoryController = new \Job\Controllers\Category($this->categoriesTable);
		$userController = new \Job\Controllers\User($userTable);
		$applicantController = new \Job\Controllers\Applicant($applicantsTable, $jobsTable);

		

		echo $route;
		if ($route == '') {
			$page = $jobController->home();
		}
		else if ($route == 'job/list') {
			$page = $jobController->list();
		}
		else if ($route == 'job/edit') {
			$page = $jobController->edit();
		}
		else if ($route == 'job/delete') {
			$page = $jobController->delete();
		}
		else if ($route == 'category/list') {
			$page = $categoryController->list();
		}
		else if ($route == 'category/edit') {
			$page = $categoryController->edit();
		}
		else if ($route == 'category/delete') {
			$page = $categoryController->delete();
		}
		else if ($route == 'user/register') {
			$page = $userController->login();
		}
		else if ($route == 'user/login') {
			$page = $userController->login();
		}
		else if ($route == 'user/logout') {
			$page = $userController->logout();
		}
		else if ($route == 'applicant/edit') {
			$page = $applicantController->edit();
		}
		else if ($route == 'applicant/list') {
			$page = $applicantController->list();
		}
		return $page;
	}


	public function getLayoutVariables(){
		return [
			'categories' => $this->categoriesTable->findAll()
		];

	}

	public function checkLogin(){
		if(!isset($_SESSION['loggedin'])){
			header('location: /job/list');
		}
	}
}