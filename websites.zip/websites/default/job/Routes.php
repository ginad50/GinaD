<?php
namespace Job;

class Routes implements \CSY2028\Routes {
	private $categoriesTable;
	public function getRoutes() {
		require '../database.php';

		$usersTable = new \CSY2028\DatabaseTable($pdo, 'user', 'id');
		$jobsTable = new \CSY2028\DatabaseTable($pdo, 'job', 'id', '\job\Entity\Job', ['$usersTable']);
		$this->categoriesTable = new \CSY2028\DatabaseTable($pdo, 'category', 'id');
		
		$applicantsTable = new \CSY2028\DatabaseTable($pdo, 'applicants', 'id');		

		$jobController = new \Job\Controllers\Job($jobsTable, $this->categoriesTable, $applicantsTable, $usersTable);
		$categoryController = new \Job\Controllers\Category($this->categoriesTable);
		$userController = new \Job\Controllers\User($usersTable);
		$applicantController = new \Job\Controllers\Applicant($applicantsTable, $jobsTable);
		
		$job = new \job\Entity\Job($usersTable);
		
		//  $job->id = 1;
		//  $job->authorId = 1;
		//  $job->getAuthor()-> firstname;

		//  echo $job->getAuthor()-> firstname;

		$job = $jobsTable->find('id','\job\Entity\Job','user');

		$routes = [
				'job/list' => [
					'GET' => [
						'controller' => $jobController, 
						'function' => 'list'
					]
				],
				'job/home' => [
					'GET' => [
						'controller' => $jobController, 
						'function' => 'home'
					]
				],
				'job/edit' => [
					'GET' => [
						'controller' => $jobController, 
						'function' => 'editForm'
					],
					'POST' => [
						'controller' => $jobController, 
						'function' => 'editSubmit'
					],
					'login' => true
				],
				'job/delete' => [
					'POST' => [
						'controller' => $jobController, 
						'function' => 'delete'
					],
					'login' => true
				],
				'category/list' => [
					'GET' => [
						'controller' => $categoryController, 
						'function' => 'list'
					]
				],
				'category/edit' => [
					'GET' => [
						'controller' => $categoryController, 
						'function' => 'editForm'
					],
					'POST' => [
						'controller' => $categoryController, 
						'function' => 'editSubmit'
					],
					'login' => true
				],	
				'category/delete' => [
					'POST' => [
						'controller' => $categoryController, 
						'function' => 'delete'
					],
					'login' => true
				],
				'user/list' => [
					'GET' => [
						'controller' => $userController, 
						'function' => 'list'
					]
				],	
				'user/edit' => [
					'GET' => [
						'controller' => $userController, 
						'function' => 'editForm'
					],
					'POST' => [
						'controller' => $userController, 
						'function' => 'editSubmit'
					],
					'login' => true
				],
				'user/login' => [
					'POST' => [
						'controller' => $userController, 
						'function' => 'login'
					],
					'GET' => [
						'controller' => $userController, 
						'function' => 'login'
					]
				],
				'user/logout' => [
					'GET' => [
						'controller' => $userController, 
						'function' => 'logout'
					],
					'login' => true
				],
				'applicant/list' => [
					'GET' => [
						'controller' => $applicantController, 
						'function' => 'list'
					],
					'login' => true
				],
				'applicant/edit' => [
					'GET' => [
						'controller' => $applicantController, 
						'function' => 'editForm'
					],
					'POST' => [
						'controller' => $applicantController, 
						'function' => 'editSubmit'
					],
					'login' => true
				],	
			];

		
		return $routes;
	}

	public function getLayoutVariables(){
		return [
			'categories' => $this->categoriesTable->findAll()
		];

	}

	public function checkLogin(){
		// session_start();
		if(!isset($_SESSION['loggedin'])){
			header('location: /job/list');
		}
	}
}


	
	