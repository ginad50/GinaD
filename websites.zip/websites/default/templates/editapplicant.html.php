<!-- <h2>Apply for <?=$job['title'];?></h2> -->

	<form action="" method="POST" enctype="multipart/form-data">
		
		<label>Your name</label>
		<input type="text" name="name" value="<?=$applicant['name'] ?? ''?>" /> 
		
		<label>E-mail address</label>
		<input type="text" name="email" value="<?=$applicant['email'] ?? ''?>" /> 
		

		<label>Cover letter</label>
		<!-- <textarea name="details"> value="<?php echo $applicant['details']; ?></textarea> -->
		<textarea name="details"> </textarea>
		
		<label>CV</label>
		<input type="file" name="cv"  />

		<input type="hidden" name="jobId" value="<?=$job['id']; ?> " />
		<!-- <input type="hidden" name="jobId" value="<?=$job['id']; echo $applicant['jobId']; ?> " /> -->
		<input type="submit" name="submit" value="Apply" />

	</form>