<form action="" method="post">
		<input type="hidden" name="job[id]" value="<?=$job['id'] ?? ''?>" />
		

		<label for="jobtext">Type your job here:</label>		
		<textarea id="jobtext" name="job[title]" rows="3" cols="40"><?=$job['jobtitle'] ?? ''?></textarea>
		<input type="submit" value="Add">
</form>