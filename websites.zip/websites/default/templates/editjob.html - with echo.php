<form action="" method="post">
		<!-- <input type="hidden" name="job[id]" value="<?=$job['id'] ?? ''?>" /> -->
		<!-- <input type="submit" value="Add"> -->

		<input type="hidden" name="id" value="<?php echo $job['id']; ?>" />			
		
		<label>Title</label>
		<input type="text" name="title" value="<?php echo $job['title']; ?>" />

		<label>Description</label>
		<textarea name="description"><?php echo $job['description']; ?></textarea>

		<label>Location</label>
		<input type="text" name="location" value="<?php echo $job['location']; ?>" />

		<label>Salary</label>
		<input type="text" name="salary" value="<?php echo $job['salary']; ?>" />

		<label>Category</label>

		<select name="categoryId">
			<?php
				foreach ($categories as $category) { 
				?> <option value="<? $category->id ?>"> <?php echo  $category['name']; ?></option>
			<?php }?>
		</select>			

			 	<!-- if ($job['categoryId'] == $row['id']) {
			 		echo '<option selected="selected" value="' . $row['id'] . '">' . $row['name'] . '</option>';
			 	}
			 	else {
			 		echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
			 	} -->



		<label>Closing Date</label>
		<input type="date" name="closingDate" value="<?php echo $job['closingDate']; ?>"  />

		<input type="submit" name="submit" value="Save" />

</form>