<form action="" method="POST">
		<input type="hidden" name="id" value="<?=$job['id'] ?? ''?>" />			
				
		<label>Title</label>
		<input type="text" name="title" value="<?=$job['title'] ?? '' ?>" />
				
		<label>Description</label>
		<!-- <textarea name="description" value ="<?=$job['description'] ?? '' ?>" > -->
		<input type="text" name="description" value ="<?=$job['description'] ?? '' ?>" />
		<label>Location</label>
		<input type="text" name="location" value="<?=$job['location'] ?? '' ?>" />

		<label>Salary</label>
		<input type="text" name="salary" value="<?=$job['salary'] ?? '' ?>" />

		<label>Category</label>

		<select name="categoryId">
			<?php
				foreach ($categories as $category) { 
				?> <option value="<? $category->id ?>"> <?php echo  $category['name']; ?></option>
			<?php }?>
		</select>			

			 	<!-- if ($job['categoryId'] == $row['id']) {
			 		echo '<option selected="selected" value="' . $row['id'] . '">' . $row['name'] . '</option>';
			 	}
			 	else {
			 		echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
			 	} -->



		<label>Closing Date</label>
		<input type="date" name="closingDate" value="<?=$job['closingDate'] ?? '' ?>" />

		<input type="submit" name="submit" value="Save" />

</form>