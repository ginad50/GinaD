<form action="" method="POST">
	<input type="hidden" name="user[id]" value="<?=$user['id'] ?? ''?>" /> 
	<label>User Name</label>
	<input type="text" name="user[username]" value="<?=$user['username'] ?? ''?>" /> 

	<label>First Name</label>
	<input type="text" name="user[firstname]" value="<?=$user['firstname'] ?? ''?>" /> 

	<label>Last Name</label>
	<input type="text" name="user[lastname]" value="<?=$user['lastname'] ?? ''?>" /> 

	<label>Password</label>
	<input type="password" name="user[password]" value="<?=$user['password'] ?? ''?>" /> 

	<label>Email</label>
	<input type="text" name="user[email]" value="<?=$user['email'] ?? ''?>" /> 

	<label>Type</label>
	<input type="text" name="user[usertype]" value="<?=$user['usertype'] ?? ''?>" /> 

	<label>Status</label>
	<input type="text" name="user[status]" value="<?=$user['status'] ?? ''?>" /> 

	<input type="submit" name="submit" value="Save" />
</form>