<h2>Jo's Jobs</h2>

<p>Welcome to Jo's Jobs, we're a recruitment agency based in Northampton. We offer a range of different office jobs. Get in touch if you'd like to list a job with us.</p>

<p>The job title is <em><?=$job['title']?></em></p>