

	<?php 

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {?>
	<h2>Jobs List</h2>

	<ul class="listing">
	<a class="new" href="/job/edit">Add new job</a>
	<?php 

		echo '<table>';
		echo '<thead>';
		echo '<tr>';
		echo '<th>Title</th>';
		echo '<th style="width: 15%">Salary</th>';
		echo '<th style="width: 5%">&nbsp;</th>';
		echo '<th style="width: 15%">&nbsp;</th>';
		echo '<th style="width: 5%">&nbsp;</th>';
		echo '<th style="width: 5%">&nbsp;</th>';
		echo '</tr>';

		// $stmt = $pdo->query('SELECT * FROM job');
		foreach ($applicants as $applicant) {
			$applicantCount['count'] = $applicant[0];
			echo $applicantCount['count'];
		}
		
		foreach ($jobs as $job) {
			// $applicants = $pdo->prepare('SELECT count(*) as count FROM applicants WHERE jobId = :jobId');

			// $applicants->execute(['jobId' => $job['id']]);

			// $applicantCount = $applicants->fetch();

			echo '<tr>';
			echo '<td>' . $job['title'] . '</td>';
			echo '<td>' . $job['salary'] . '</td>';
			echo '<td><a style="float: right" href="/job/edit?id=' . $job['id'] . '">Edit</a></td>';
			// echo '<td><a style="float: right" method="post" href="/applicant/list?id=' . $job['id'] . '">View applicants (' . $applicantCount['count'] . ') </a></td>';
			echo '<td><a style="float: right" method="post" href="/applicant/list?id=' . $job['id'] . '">View applicants </a></td>';
			// echo '<td><a style="float: right" href="applicants/list?id=' . $job['id'] . '">View applicants (' . $applicantCount['count'] . ')</a></td>';
			echo '<td><form method="post" action="deletejob.php">
			<input type="hidden" name="id" value="' . $job['id'] . '" />
			<input type="submit" name="submit" value="Delete" />
			</form></td>';
			echo '</tr>';
		}

		echo '</thead>';
		echo '</table>';

} else {?>

	<section class="right">

	<h1>Human Resources Jobs</h1>

	<ul class="listing">
	<?php print_r($jobs);
	
	?>

	<?php foreach ($jobs as $job) {
		echo '<li>';
		// echo $job->getUser()->name; 
		echo '<div class="details">';
		// echo '<h2>' . $job['title'] . '</h2>';  // Need this but title not coming through
		// echo '<h3>' . $job['salary'] . '</h3>'; // Need this but salary not coming through

		echo '<h2>' . $job->id . '</h2>';			//  Only the applicant!! fields are coming through
		echo '<h3>' . $job->name . '</h3>';			//  Only the userTable fields are coming through
		echo '<h3>' . $job->email . '</h3>';			//  Only the userTable fields are coming through
		echo '<p>' . nl2br($job->description) . '</p>';	// When I remove this nothing is displaying
		echo '<p>' . nl2br($job['description']);
		// echo '<p>' . nl2br($job['description']) . '</p>';		// Therefore cannot yet call this

		// echo '<a class="more" href="/applicant/edit?id=' . $job['id'] . '">Apply for this job</a>'; // Therefore cannot yet call this
		// echo '<a class="more" href="/applicant/edit?id=' . $job['id'] . '">Apply for this job</a>'; // Therefore cannot yet call this

		echo '</div>';
		echo '</li>';
	}
}	
?>

</ul>

</section>