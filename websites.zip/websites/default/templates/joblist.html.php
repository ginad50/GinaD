
	<h2>Jobs List</h2>

	<ul class="listing">
	<a class="new" href="/job/edit">Add new job</a>
	<?php 

		echo '<table>';
		echo '<thead>';
		echo '<tr>';
		echo '<th>Title</th>';
		echo '<th style="width: 15%">Salary</th>';
		echo '<th style="width: 5%">&nbsp;</th>';
		echo '<th style="width: 15%">&nbsp;</th>';
		echo '<th style="width: 5%">&nbsp;</th>';
		echo '<th style="width: 5%">&nbsp;</th>';
		echo '</tr>';

		
		foreach ($jobs as $job) {
			echo '<tr>';
			
			echo '<td>' . $job->title . '</td>';			
			echo '<td>' . $job->salary . '</td>';
			echo $job->getAuthor()->id;
			echo $job->getAuthor()->firstname;
			


			echo '<td>' . $job['title'] . '</td>';
			// echo '<td>' . $job['salary'] . '</td>';
			echo '<td><a style="float: right" href="/job/edit?id=' . $job['id'] . '">Edit</a></td>';
			// echo '<td><a style="float: right" method="post" href="/applicant/list?id=' . $job['id'] . '">View applicants (' . $applicantCount['count'] . ') </a></td>';
			echo '<td><a style="float: right" method="post" href="/applicant/list?id=' . $job['id'] . '">View applicants </a></td>';
			// echo '<td><a style="float: right" href="applicants/list?id=' . $job['id'] . '">View applicants (' . $applicantCount['count'] . ')</a></td>';
			echo '<td><form method="post" action="deletejob.php">
			<input type="hidden" name="id" value="' . $job['id'] . '" />
			<input type="submit" name="submit" value="Delete" />
			</form></td>';
			echo '</tr>';
		}

		echo '</thead>';
		echo '</table>';
?>

</ul>

</section>