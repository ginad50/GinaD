<!doctype html>
<html>
  <head>
    <link rel="stylesheet" href="/jobs.css">
    <title><?=$title?></title>
  </head>
  <body>
  <nav>
    <header>
    <section>
			<aside>
				<h3>Office Hours:</h3>
				<p>Mon-Fri: 09:00-17:30</p>
				<p>Sat: 09:00-17:00</p>
				<p>Sun: Closed</p>
			</aside>

      <h1>Jo's Jobs</h1>
    </header>
    <nav>
		<ul>
			<li><a href="/">Home</a></li>
			<li>Jobs
				<ul>
        <?php
        foreach ($categories as $category) {
            echo '<li><a href="/job/list">'.$category['name'].'</a></li>';
        }?>

				</ul>
			</li>
			<li><a href="/about.html">About Us</a></li>
		</ul>
    
	</nav>
	<img src="/images/randombanner.php"/>

  
    <!-- <ul>
      <li><a href="/">Home</a></li>
      <li><a href="/job/list">Jobs List</a></li>
      <li><a href="/job/edit">Add a new Job</a></li>
      <li><a href="/category/list">Category List</a></li>
      <li><a href="/category/edit">Add a new Category</a></li>
    </ul> -->
  </nav>

  <main class="sidebar">
  <section class="left">
		<ul>
    <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {?>

      <li><a href="/job/list">Jobs</a></li>
			<li><a href="/category/list">Categories</a></li>

      <br><br>
      <li><a href="/user/edit">Register User</a></li>
      <li><a href="/user/logout">Log out</a></li>
      <?php } else {?>
      <?php
        foreach ($categories as $category) {
            echo '<li><a href="/job/list">'.$category['name'].'</a></li>';
      }?>
			    
      <br><br>
      <li><a href="/user/login">Login</a></li>
      <?php }?>

      <!-- <li><a href="jobs.php">Jobs</a></li>
			<li><a href="categories.php">Categories</a></li> -->

		</ul>
	</section>
  <section class="right">
  </section>

  <?=$output?>
  </main>

  <footer>
  &copy; Jo's Jobs 2020
  </footer>
  </body>
</html>