<?php foreach($jobs as $job) { ?>
<blockquote>
<p>
	<?=$job['title']?> 
	<a href="/job/edit?id=<?=$job['id']?>">edit</a>

	<form action="/job/delete" method="POST">
		<input type="hidden" name="id" value="<?=$job['id']?>" />
		<input type="submit" value="Delete" />
	</form>

</p>
</blockquote>
<?php } ?>